public interface INormalizer
{
    string Normalize(string token);
}
