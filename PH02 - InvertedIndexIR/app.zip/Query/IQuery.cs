public interface IQuery
{
   void ParseInput(string input);
   List<string> getWordsOfType(string notation);
}