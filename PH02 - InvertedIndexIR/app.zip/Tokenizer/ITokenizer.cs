public interface ITokenizer
{
    string[] Tokenize(string text);
}
